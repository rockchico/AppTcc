KalmanJS
========

JavaScript implementation and interactive playground for Kalman filters.